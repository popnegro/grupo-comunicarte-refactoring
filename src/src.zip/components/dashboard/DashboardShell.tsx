import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  BarChart3, ExternalLink, LogOut, FileText, MonitorSmartphone, MapPin, Bell, ChevronRight,
  Menu, X, FilePlus2, PanelLeft,
} from 'lucide-react';
import { NavLink, useLocation, useNavigate, Link } from 'react-router-dom';
import { apiFetch } from '../../lib/api';

interface DashboardShellProps { children: ReactNode; }

const pageLabels: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/dashboard/soportes': 'Inventario',
  '/dashboard/soportes/new': 'Nuevo soporte',
  '/dashboard/solicitudes': 'Solicitudes Media Kit',
  '/dashboard/mediakits': 'Solicitudes Media Kit',
  '/dashboard/mediakits/nuevo': 'Crear Media Kit',
};

export function DashboardShell({ children }: DashboardShellProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [newLeadsCount, setNewLeadsCount] = useState(0);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    let cancelled = false;
    apiFetch('/api/admin/stats')
      .then((response) => {
        if (!cancelled) setAuthChecked(response.ok);
      })
      .catch(() => {
        if (!cancelled) setAuthChecked(false);
      });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!authChecked) return;
    let cancelled = false;

    const loadNewLeadsCount = async () => {

      try {
        const response = await apiFetch('/api/admin/requests', {
          
        });
        if (!response.ok) return;

        const json = await response.json();
        if (cancelled || json.status !== 'success' || !Array.isArray(json.data)) return;

        setNewLeadsCount(
          json.data.filter((lead: { status?: string }) =>
            lead.status === 'nuevo' || lead.status === 'pending'
          ).length
        );
      } catch {
        // The shell remains usable if the notification count cannot be loaded.
      }
    };

    loadNewLeadsCount();
    return () => {
      cancelled = true;
    };
  }, [location.pathname, authChecked]);

  useEffect(() => { setMobileNavOpen(false); }, [location.pathname]);

  const currentPage = useMemo(() => {
    if (pageLabels[location.pathname]) return pageLabels[location.pathname];
    if (location.pathname.includes('/edit')) return 'Editar soporte';
    if (location.pathname.includes('/preview')) return 'Vista previa';
    if (location.pathname.includes('/reservation')) return 'Reserva';
    return 'Panel';
  }, [location.pathname]);

  const navClass = ({ isActive }: { isActive: boolean }) =>
    `group relative flex min-h-10 items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${isActive ? 'bg-gray-950 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-950'}`;

  const handleLogout = () => {
    void apiFetch('/api/admin/logout', { method: 'POST' }).finally(() => {
      navigate('/login');
    });
  };

  // Use existing routes only: no placeholder destinations are added to the sidebar.
  const navGroups = [
    {
      label: 'Principal',
      items: [
        { to: '/dashboard', label: 'Dashboard', icon: BarChart3, end: true },
        { to: '/dashboard/soportes', label: 'Inventario', icon: MonitorSmartphone },
        { to: '/dashboard/solicitudes', label: 'Solicitudes Media Kit', icon: FileText, count: newLeadsCount },
        { to: '/dashboard/mediakits/nuevo', label: 'Propuestas', icon: FilePlus2 },
      ],
    },
  ];

  if (!authChecked) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50 text-sm text-gray-500">Validando sesión…</div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f4f5f3] font-sans text-gray-900 selection:bg-gray-950 selection:text-white">
      <header className="sticky top-0 z-50 h-16 border-b border-gray-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-full w-full max-w-[1680px] items-center justify-between px-3 sm:px-5 lg:px-6">
          <div className="flex min-w-0 items-center gap-2">
            <button type="button" onClick={() => setMobileNavOpen((open) => !open)} className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 md:hidden" aria-label={mobileNavOpen ? 'Cerrar navegación' : 'Abrir navegación'} aria-expanded={mobileNavOpen}>
              {mobileNavOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
            <button type="button" onClick={() => setSidebarCollapsed((collapsed) => !collapsed)} className="hidden h-8 w-8 items-center justify-center rounded-md text-gray-500 hover:bg-gray-100 hover:text-gray-950 md:inline-flex" aria-label={sidebarCollapsed ? 'Expandir navegación' : 'Colapsar navegación'} title={sidebarCollapsed ? 'Expandir navegación' : 'Colapsar navegación'}>
              <PanelLeft className="h-4 w-4" />
            </button>
            <Link to="/dashboard" className="flex shrink-0 items-center" title="Ir al resumen"><img src="/brand/brand-dark.svg" alt="Grupo Comunicarte" className="h-6 w-auto" /></Link>
          </div>
          <div className="flex items-center gap-1.5">
            <Link to="/dashboard/solicitudes" className="relative rounded-md p-2 text-gray-500 transition hover:bg-gray-100 hover:text-gray-950" title={`${newLeadsCount} solicitudes nuevas`} aria-label="Solicitudes nuevas"><Bell className="h-4 w-4" />{newLeadsCount > 0 && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-emerald-500 ring-2 ring-white" />}</Link>
            <Link to="/inventario" className="hidden items-center gap-1.5 rounded-md border border-gray-200 px-2.5 py-1.5 text-xs font-medium text-gray-700 transition hover:border-gray-300 hover:bg-gray-50 sm:inline-flex" title="Abrir inventario público"><MapPin className="h-3.5 w-3.5 text-gray-500" />Ver inventario</Link>
            <div className="hidden items-center gap-2 border-l border-gray-200 pl-3 sm:flex"><div className="flex h-7 w-7 items-center justify-center rounded-md bg-gray-950 text-[10px] font-bold text-white">GC</div><div className="hidden text-left leading-tight lg:block"><span className="block text-xs font-semibold text-gray-950">Editor</span><span className="text-[10px] text-gray-500">Espacio de trabajo</span></div></div>
            <button type="button" onClick={handleLogout} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-gray-200 bg-white px-2 text-xs font-medium text-gray-700 transition hover:border-red-200 hover:bg-red-50 hover:text-red-700" title="Cerrar sesión" aria-label="Cerrar sesión"><LogOut className="h-3.5 w-3.5" /><span className="hidden sm:inline">Salir</span></button>
          </div>
        </div>
      </header>

      <div className="relative mx-auto flex w-full max-w-[1600px]">
        {mobileNavOpen && <button type="button" aria-label="Cerrar menú" onClick={() => setMobileNavOpen(false)} className="fixed inset-0 top-14 z-30 bg-gray-950/20 md:hidden" />}
        <aside className={`${mobileNavOpen ? 'translate-x-0' : '-translate-x-full'} fixed left-0 top-16 bottom-0 z-40 w-[280px] border-r border-gray-200 bg-white px-3 py-4 shadow-xl transition-all duration-200 md:static md:z-auto md:block md:translate-x-0 md:shadow-none ${sidebarCollapsed ? 'md:w-[68px]' : 'md:w-56 lg:w-60'}`}>
          <nav aria-label="Navegación principal del panel" className="space-y-6">
            {navGroups.map((group) => (
              <div key={group.label}>
                {!sidebarCollapsed && <div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-gray-400">{group.label}</div>}
                <div className="space-y-0.5">
                  {group.items.map(({ to, label, icon: Icon, end, count }: any) => (
                    <NavLink key={to} to={to} end={end} className={navClass} title={sidebarCollapsed ? label : undefined}>
                      {({ isActive }) => <><Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-emerald-600' : 'text-gray-400'}`} /><span className={sidebarCollapsed ? 'sr-only' : ''}>{label}</span>{count ? <span className={`${sidebarCollapsed ? 'ml-auto h-1.5 w-1.5 p-0' : 'ml-auto px-1.5 py-0.5'} shrink-0 rounded-full bg-emerald-50 text-[10px] font-semibold text-emerald-800 ${sidebarCollapsed ? 'bg-emerald-500' : ''}`}>{sidebarCollapsed ? null : count}</span> : null}{isActive && !sidebarCollapsed && <ChevronRight className="ml-auto h-3 w-3 text-gray-400" />}</>}
                    </NavLink>
                  ))}
                </div>
              </div>
            ))}
          </nav>

          <div className="mt-5 border-t border-gray-100 pt-5">
            <Link to="/inventario" title={sidebarCollapsed ? 'Inventario público' : undefined} className="flex min-h-9 items-center gap-3 rounded-md px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-950"><MapPin className="h-4 w-4 shrink-0 text-gray-400" /><span className={sidebarCollapsed ? 'sr-only' : ''}>Inventario público</span><ExternalLink className={sidebarCollapsed ? 'hidden' : 'ml-auto h-3 w-3 text-gray-400'} /></Link>
          </div>
        </aside>

        <main className="min-w-0 flex-1 px-4 py-6 sm:px-7 sm:py-7 lg:px-10 lg:py-9">
          <div className="mb-7 flex min-h-5 items-center gap-2 text-xs" aria-label="Breadcrumb"><Link to="/dashboard" className="font-medium text-gray-500 hover:text-gray-950">Resumen</Link>{location.pathname !== '/dashboard' && <><ChevronRight className="h-3 w-3 text-gray-300" aria-hidden="true" /><span className="font-medium text-gray-900" aria-current="page">{currentPage}</span></>}</div>
          {children}
        </main>
      </div>
    </div>
  );
}
